"""Collect bounded Git history and test offline source restore. Executes Git only.
Run python3 -I from outside downloaded directories. Never executes upstream code.
"""
import hashlib
import json
import os
import pathlib
import resource
import signal
import subprocess
import time

ROOT=pathlib.Path(__file__).parent
HISTORY=ROOT/'git-history'
DELIVERY=ROOT/'delivery'
LIMIT=250*1024*1024
REPOS=[
 ('libredwg-web','https://github.com/mlightcad/libredwg-web.git','2654a724bce3d5f588a0d16b6426a23e3f0fef46','v0.7.17','libredwg-web-0.7.17-2654a724','libredwg-web'),
 ('jsmn','https://github.com/zserge/jsmn.git','85695f3d5903b1cd5b4030efe50db3b4f5f3c928',None,'jsmn-85695f3d','jsmn'),
 ('realdwg-web','https://github.com/mlightcad/realdwg-web.git','ae0d603bd4e3cad0d8d415c53338d84b14b8c125','v1.15.17','realdwg-web-1.15.17-ae0d603b','realdwg-web'),
]
ENV=dict(os.environ,GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',GIT_LFS_SKIP_SMUDGE='1')
GIT=['git','-c','core.hooksPath=/dev/null','-c','gc.auto=0']


def nbytes(path):
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())


def cap_file_size():
    resource.setrlimit(resource.RLIMIT_FSIZE,(LIMIT,LIMIT))


def command(args,log,offline=False,budget_path=None,timeout=240):
    env=ENV.copy()
    if offline:
        env['GIT_ALLOW_PROTOCOL']='file'
        env['http_proxy']='http://127.0.0.1:9'
        env['https_proxy']='http://127.0.0.1:9'
    with log.open('wb') as output:
        proc=subprocess.Popen(GIT+args,cwd='/',env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=cap_file_size)
        end=time.monotonic()+timeout
        while proc.poll() is None:
            size=nbytes(budget_path) if budget_path else 0
            if size>LIMIT or time.monotonic()>end:
                os.killpg(proc.pid,signal.SIGTERM)
                proc.wait(timeout=15)
                raise RuntimeError(f'STOP: size/time budget exceeded; size={size}; log={log}')
            try:
                proc.wait(timeout=.5)
            except subprocess.TimeoutExpired:
                pass
    if proc.returncode:
        raise RuntimeError(f'Git failed ({proc.returncode}); log={log}; last bytes={log.read_bytes()[-1500:]!r}')


def output(args,offline=True):
    env=ENV.copy()
    if offline:env['GIT_ALLOW_PROTOCOL']='file'
    return subprocess.check_output(GIT+args,cwd='/',env=env,stderr=subprocess.PIPE)


def save(path,obj):
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')


def verify_checkout(label,path):
    expected=json.loads((ROOT/'evidence'/f'git-tree-{label}.json').read_bytes())
    assert not expected['truncated']
    actual={}
    for entry in output(['-C',str(path),'ls-tree','-rz','--full-tree','HEAD']).split(b'\0'):
        if not entry:continue
        meta,name=entry.split(b'\t',1);mode,kind,sha=meta.decode().split();actual[name.decode()]={'mode':mode,'type':kind,'sha':sha}
    want={x['path']:{'mode':x['mode'],'type':x['type'],'sha':x['sha']} for x in expected['tree'] if x['type']!='tree'}
    assert actual==want,f'{label}: tree object set mismatch'
    checked=0
    for rel,item in actual.items():
        if item['type']!='blob':continue
        p=path/rel
        b=str(p.readlink()).encode() if p.is_symlink() else p.read_bytes()
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==item['sha'],str(p)
        checked+=1
    return {'git_tree_entries':len(actual),'checkout_blobs_verified':checked,'head':output(['-C',str(path),'rev-parse','HEAD']).decode().strip(),'status_porcelain':output(['-C',str(path),'status','--porcelain']).decode()}


def main():
    HISTORY.mkdir(exist_ok=True)
    DELIVERY.mkdir(exist_ok=True)
    logs=HISTORY/'logs';logs.mkdir(exist_ok=True)
    mirrors=HISTORY/'mirrors';mirrors.mkdir(exist_ok=True)
    bundles=DELIVERY/'git-bundles';bundles.mkdir(exist_ok=True)
    records=[]
    for name,url,sha,tag,tree_label,evidence_label in REPOS:
        mirror=mirrors/(name+'.git')
        if not mirror.exists():
            command(['clone','--mirror',url,str(mirror)],logs/(name+'-clone.log'),budget_path=mirrors)
        assert output(['-C',str(mirror),'cat-file','-t',sha])==b'commit\n'
        if tag:assert output(['-C',str(mirror),'rev-parse',tag+'^{commit}']).decode().strip()==sha
        # Dedicated local ref guarantees that pinned revisions survive any remote ref policy.
        command(['-C',str(mirror),'update-ref','refs/source-delivery/pinned',sha],logs/(name+'-pin.log'),offline=True)
        bundle=bundles/(name+'-history.bundle')
        if not bundle.exists():
            command(['-C',str(mirror),'bundle','create',str(bundle),'--all'],logs/(name+'-bundle-create.log'),offline=True,budget_path=bundles)
        command(['-C',str(mirror),'bundle','verify',str(bundle)],logs/(name+'-bundle-verify.log'),offline=True)
        with bundle.open('rb') as f:
            header=[]
            while True:
                line=f.readline()
                if not line or line==b'\n':break
                header.append(line.decode().rstrip('\n'))
        assert not any(x.startswith('-') for x in header),'Bundle has missing history prerequisites'
        record={'repository':url,'name':name,'pinned_commit':sha,'tag':tag,'pin_ref':'refs/source-delivery/pinned','bundle':str(bundle.relative_to(DELIVERY)),'bundle_bytes':bundle.stat().st_size,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'mirror_bytes':nbytes(mirror),'commit_count':int(output(['-C',str(mirror),'rev-list','--all','--count'])),'bundle_self_contained_no_prerequisites':True,'refs':output(['-C',str(mirror),'show-ref']).decode().splitlines()}
        records.append(record)
        print(json.dumps({k:record[k] for k in ['name','pinned_commit','bundle_bytes','bundle_sha256','mirror_bytes','commit_count']}),flush=True)
        save(DELIVERY/'GIT-BUNDLES.json',{'source_status':'Collection in progress; offline restore required','repositories':records})
    restores=HISTORY/'offline-restore';restores.mkdir(exist_ok=True)
    restored={}
    for name,url,sha,tag,tree_label,evidence_label in REPOS:
        if name=='jsmn':continue
        target=restores/name
        if not target.exists():
            command(['clone','--no-checkout',str(bundles/(name+'-history.bundle')),str(target)],logs/(name+'-offline-clone.log'),offline=True,budget_path=target/'.git')
        command(['-C',str(target),'checkout','--detach',sha],logs/(name+'-offline-checkout.log'),offline=True)
        restored[name]=target
    web=restored['libredwg-web']
    command(['-C',str(web),'config','submodule.jsmn.url',str(bundles/'jsmn-history.bundle')],logs/'jsmn-local-url.log',offline=True)
    command(['-c','protocol.file.allow=always','-C',str(web),'submodule','update','--init','--recursive'],logs/'jsmn-offline-restore.log',offline=True,budget_path=web/'.git/modules')
    restored['jsmn']=web/'jsmn'
    proof={}
    for name in ['libredwg-web','jsmn','realdwg-web']:
        proof[name]=verify_checkout(name,restored[name])
        assert proof[name]['status_porcelain']=='',f'{name}: restored working tree changed'
        assert proof[name]['head']==next(x[2] for x in REPOS if x[0]==name)
    wasm=web/'bindings/javascript/wasm/libredwg-web.wasm'
    runtime=ROOT.parent/'dwg viewer/src/vendor/libredwg-web.wasm'
    candidate=next((ROOT/'trees/libredwg-web-0.7.17-2654a724').iterdir())/'bindings/javascript/wasm/libredwg-web.wasm'
    assert wasm.read_bytes()==runtime.read_bytes()==candidate.read_bytes()
    proof['wasm_sha256']=hashlib.sha256(wasm.read_bytes()).hexdigest()
    proof['network_policy']='Fresh restore allowed Git file protocol ONLY (GIT_ALLOW_PROTOCOL=file); network proxy additionally points at closed localhost port. Source C/JS was never executed.'
    proof['submodule_status']=output(['-C',str(web),'submodule','status','--recursive']).decode().strip()
    proof['tool_scope']='Git clone/checkouts, bundle verify/list, source-tree/blob comparisons only; NO autogen/configure/compiler/package install/build execution.'
    denied_env=ENV.copy();denied_env['GIT_ALLOW_PROTOCOL']='file'
    denied=subprocess.run(GIT+['ls-remote',REPOS[0][1]],cwd='/',env=denied_env,capture_output=True)
    assert denied.returncode != 0 and b'not allowed' in denied.stderr, 'Git network transport restriction did not reject HTTPS'
    proof['network_transport_negative_control']={'operation':'git ls-remote real upstream HTTPS URL with GIT_ALLOW_PROTOCOL=file','exit_code':denied.returncode,'stderr':denied.stderr.decode(),'rejected':True}
    save(ROOT/'evidence/offline-git-restore.json',proof)
    save(DELIVERY/'GIT-BUNDLES.json',{'source_status':'Exact pinned checkout + submodule restored offline and all 2004 blobs verified','history_storage_scope':'Full repository history and all fetched refs, with explicit pinned source-delivery refs; each bundle has no prerequisites','repositories':records,'restore_proof':'evidence/offline-git-restore.json','total_bundle_bytes':sum(x['bundle_bytes'] for x in records),'total_mirror_bytes':sum(x['mirror_bytes'] for x in records)})
    print('OFFLINE_RESTORE_PASS',json.dumps(proof),flush=True)

if __name__=='__main__':main()

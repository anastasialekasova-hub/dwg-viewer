"""Download and safely inspect source archives as data; never execute them."""
import argparse, hashlib, io, json, pathlib, subprocess, tarfile
ROOT=pathlib.Path(__file__).parent

def fetch(url, destination):
    if destination.exists():
        raise RuntimeError('Refusing overwrite: '+str(destination))
    subprocess.run(['curl','--fail','--location','--silent','--show-error','--retry','2','--output',str(destination),url],check=True,cwd='/')
    return hashlib.sha256(destination.read_bytes()).hexdigest()

def archive(repo, commit, label):
    folder=ROOT/'downloads'/label
    folder.mkdir(parents=True,exist_ok=False)
    path=folder/(label+'.tar.gz')
    url=f'https://codeload.github.com/{repo}/tar.gz/{commit}'
    digest=fetch(url,path)
    tree=ROOT/'trees'/label
    tree.mkdir(parents=True,exist_ok=False)
    with tarfile.open(path,'r:gz') as tf:
        members=tf.getmembers()
        for m in members:
            p=pathlib.PurePosixPath(m.name)
            if p.is_absolute() or '..' in p.parts or not (m.isfile() or m.isdir() or m.issym() or m.islnk()):
                raise RuntimeError('Unsafe member '+m.name)
        tf.extractall(tree,filter='data')
    record={'repository':repo,'commit':commit,'url':url,'archive':str(path.relative_to(ROOT)),'sha256':digest,'tree':str(tree.relative_to(ROOT)),'members':len(members)}
    (folder/'origin.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('repo');ap.add_argument('commit');ap.add_argument('label');a=ap.parse_args();archive(a.repo,a.commit,a.label)

"""Produce deterministic candidate-source archive and inventories without executing source."""
import csv
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import stat
import tarfile

ROOT = pathlib.Path(__file__).parent

def tree(label):
    roots = list((ROOT/'trees'/label).iterdir())
    assert len(roots) == 1
    return roots[0]

def jsonwrite(path, obj):
    path.write_text(json.dumps(obj, sort_keys=True, indent=2)+'\n')

web = tree('libredwg-web-0.7.17-2654a724')
converter = tree('realdwg-web-1.15.17-ae0d603b')
jsmn = tree('jsmn-85695f3d')
web_pkg = json.loads((web/'bindings/javascript/package.json').read_bytes())
conv_pkg = json.loads((converter/'packages/libredwg-converter/package.json').read_bytes())
conv_root = json.loads((converter/'package.json').read_bytes())
inputs = {
    'status': 'PREFERRED_SOURCE_DELIVERY_AND_OFFLINE_GIT_RESTORE_VERIFIED; BUILDABILITY_AND_BIT_REPRODUCTION_NOT_RUN',
    'web': {
        'source': 'sources/libredwg-web',
        'license': 'sources/libredwg-web/COPYING',
        'recursive_submodules': [{'path':'jsmn','repository':'zserge/jsmn','commit':'85695f3d5903b1cd5b4030efe50db3b4f5f3c928','recursive_children':[]}],
        'actual_upstream_npm_scripts': web_pkg['scripts'],
        'javascript_dev_dependencies': web_pkg['devDependencies'],
        'lockfile': 'sources/libredwg-web/bindings/javascript/pnpm-lock.yaml',
        'lock_inventory': 'evidence/lock-inventory-libredwg-web.json',
        'ci_js_environment': {'runner':'ubuntu-latest','Node':'24 (major only)','pnpm':'9 (major only)','npm':'11 (major only)'},
        'native_build_tools': ['GNU autoconf >=2.69','GNU automake >=1.14','GNU libtool','GNU make','shell','Perl for source-generation rules','gperf for optional regeneration of tracked generated C tables','Emscripten emcc/emconfigure/emmake'],
        'known_compiler_link_inputs': ['Tracked LibreDWG src/*.c and include/*','bindings/javascript/embind/*.cpp and header','Emscripten embind','Emscripten -sUSE_ZLIB=1 port','Emscripten libc/libc++ and -sMALLOC=mimalloc runtime'],
        'historical_reproduction_unknowns_not_missing_project_source': ['Emscripten/LLVM release','zlib port source version/hash','Emscripten mimalloc/runtime revisions','configure/generated config.h and .version values','compiler/link invocation actually used for committed binary'],
        'bootstrap': 'Use exact Git checkout restored from bundled full history plus pinned local jsmn bundle, as documented in BOOTSTRAP/BUILD.md. Original autogen/version-gen use authentic Git history; configure/Makefile.in/config.h are standard generated outputs. No fabricated metadata or patched source. Restore verified; native bootstrap NOT RUN.'
    },
    'converter': {
        'source': 'sources/realdwg-web/packages/libredwg-converter',
        'license': 'sources/realdwg-web/packages/libredwg-converter/LICENSE',
        'root_monorepo_license': 'MIT, distinct from GPL converter package',
        'actual_upstream_npm_scripts': conv_pkg['scripts'],
        'dependencies': conv_pkg['dependencies'],
        'dev_dependencies': conv_pkg['devDependencies'],
        'peer_dependencies': conv_pkg['peerDependencies'],
        'root_dev_dependencies': conv_root['devDependencies'],
        'package_manager': conv_root['packageManager'],
        'lockfile': 'sources/realdwg-web/pnpm-lock.yaml',
        'lock_inventory': 'evidence/lock-inventory-realdwg-web.json',
        'ci_environment': {'runner':'ubuntu-latest','Node':'22.14.0','pnpm':conv_root['packageManager'],'npm':'11 (major only)'},
        'workspace_sources': sorted(p.name for p in (converter/'packages').iterdir() if p.is_dir()),
        'native_submodules': [],
        'upstream_web_dependency_locked': '0.8.2 for original upstream converter DIST build, not substituted into the shipped product. Product overrides to 0.7.17, bundles converter lib/ worker and separately copies web 0.7.17 WASM; sources for that pinned shipped web are included.',
        'downstream_extension_web_override': '0.7.17',
        'js_tool_package_cache': 'NOT vendored; package resolutions and integrity hashes retained in upstream locks and lock-inventory JSON.'
    },
    'safety': 'All listed commands are upstream DATA for audit, NOT authorization/instructions to execute untrusted downloads.'
}
jsonwrite(ROOT/'BUILD-INPUTS.json', inputs)

# Virtual archive assembly preserves raw snapshots; only jsmn mount is added.
entries = {}
for base, prefix in [(web,'sources/libredwg-web'),(converter,'sources/realdwg-web'),(jsmn,'sources/libredwg-web/jsmn')]:
    entries[prefix] = base
    for path in base.rglob('*'):
        entries[prefix+'/'+str(path.relative_to(base))] = path
for path in sorted((ROOT/'evidence').rglob('*')):
    entries[str(path.relative_to(ROOT))] = path
for path in sorted((ROOT/'downloads').glob('*/origin.json')):
    entries[str(path.relative_to(ROOT))] = path
for name in ['PROVENANCE.json','BUILD-INPUTS.json','collect_sources.py','verify_sources.py','package_candidates.py','prepare_git_delivery.py','BOOTSTRAP/BUILD.md']:
    entries[name] = ROOT/name
entries['GIT-BUNDLES.json'] = ROOT/'delivery/GIT-BUNDLES.json'

inventory = []
for name,path in sorted(entries.items()):
    if path.is_symlink():
        data = str(path.readlink()).encode();kind = 'symlink';mode = '0777'
    elif path.is_dir():
        data = b'';kind = 'directory';mode = '0755'
    elif path.is_file():
        data = path.read_bytes();kind = 'file';mode = '0755' if path.stat().st_mode & stat.S_IXUSR else '0644'
    else:
        raise RuntimeError('Unexpected file type: '+str(path))
    inventory.append({'path':name,'type':kind,'mode':mode,'size':len(data),'sha256':hashlib.sha256(data).hexdigest() if kind != 'directory' else None})
jsonwrite(ROOT/'INVENTORY.json', {'format':'Candidate bundle inventory; paths inside archive; symlink hash is UTF-8 link target','entries':inventory})
entries['INVENTORY.json'] = ROOT/'INVENTORY.json'

archive = ROOT/'delivery/dwg-viewer-gpl-component-sources.tar.gz'
# Fixed ordering/timestamps/ownership and gzip header: same inputs => same bytes.
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tf:
            for name,path in sorted(entries.items()):
                info = tarfile.TarInfo(name);info.uid=0;info.gid=0;info.uname='';info.gname='';info.mtime=0
                if path.is_symlink():
                    info.type=tarfile.SYMTYPE;info.linkname=str(path.readlink());info.mode=0o777;tf.addfile(info)
                elif path.is_dir():
                    info.type=tarfile.DIRTYPE;info.mode=0o755;tf.addfile(info)
                else:
                    data=path.read_bytes();info.size=len(data);info.mode=0o755 if path.stat().st_mode & stat.S_IXUSR else 0o644;tf.addfile(info,io.BytesIO(data))

delivery = ROOT/'delivery'
for name in ['PROVENANCE.json','BUILD-INPUTS.json','INVENTORY.json','BOOTSTRAP/BUILD.md']:
    target = delivery/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/name,target)
checks = []
for path in sorted(delivery.rglob('*')):
    if path.is_file() and not path.is_symlink() and path.name != 'SHA256SUMS':
        checks.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+str(path.relative_to(delivery)))
(delivery/'SHA256SUMS').write_text('\n'.join(checks)+'\n')
# Root index covers the delivery assets and the current authoring/metadata files, not scratch mirrors/restores.
root_checks = [line.split('  ',1)[0]+'  delivery/'+line.split('  ',1)[1] for line in checks]
for name in ['PROVENANCE.json','BUILD-INPUTS.json','INVENTORY.json','BOOTSTRAP/BUILD.md','collect_sources.py','verify_sources.py','package_candidates.py','prepare_git_delivery.py','delivery/SHA256SUMS']:
    root_checks.append(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()+'  '+name)
(ROOT/'SHA256SUMS').write_text('\n'.join(sorted(root_checks))+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'inventory_entries':len(inventory),'total_delivery_bytes':sum(p.stat().st_size for p in delivery.rglob('*') if p.is_file()),'status':'SOURCE DELIVERY ASSEMBLED; OFFLINE RESTORE VERIFIED; BUILDS NOT RUN'}))

# Pinned component source delivery

This file documents the source-delivery assets, the verified Git-only offline restore, and the **unexecuted upstream build procedure**. It is not a successful-build, bit-reproducibility, or legal-compliance certification. No runtime binary or upstream tracked source/configuration was changed.

## 1. Delivery set and exact identities

Keep the source archive and **all three** files in `git-bundles/` together. `GIT-BUNDLES.json` records every bundle's checksum, size, preserved refs and pin; `SHA256SUMS` covers the delivered files. The source archive contains the source snapshots, licenses, this document and the evidence. Git bundles supply authentic history/refs that a GitHub source archive omits.

| Component | Exact source commit | Ref / purpose |
|---|---|---|
| libredwg-web 0.7.17 / LibreDWG fork | `2654a724bce3d5f588a0d16b6426a23e3f0fef46` | `v0.7.17`; native source, embind, TypeScript and build scripts |
| jsmn | `85695f3d5903b1cd5b4030efe50db3b4f5f3c928` | Exact LibreDWG Git submodule, not latest |
| libredwg-converter 3.15.17 | `ae0d603bd4e3cad0d8d415c53338d84b14b8c125` | Monorepo tag `v1.15.17`, **not** `v3.15.17` |

Each bundle is self-contained, with no prerequisite commit objects. It retains the fetched repository history/tags/refs and an explicit `refs/source-delivery/pinned` ref. Do not replace the fork with an unrelated GNU LibreDWG release: that would lose the fork's JavaScript/native changes.

## 2. Verified offline restore: Git only

The following is the same Git-only approach used for verification. Use a new empty destination, outside any existing checkout. Downloaded source is untrusted; this block does not run package scripts, autogen, configure, compilers, source interpreters, or hooks.

First verify `SHA256SUMS` with an available SHA-256 tool, for example `shasum -a 256 -c SHA256SUMS` from the delivery directory. The absolute delivery location below must contain `git-bundles/`; the restoration path must not already exist.

```sh
DELIVERY='/absolute/path/to/delivery'
RESTORE='/absolute/path/to/new-restored-sources'
test ! -e "$RESTORE" || exit 1
mkdir "$RESTORE"

# Disable external Git configuration and prohibit network transports.
export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL=/dev/null
export GIT_TERMINAL_PROMPT=0
export GIT_LFS_SKIP_SMUDGE=1
export GIT_ALLOW_PROTOCOL=file

# Full Git history/refs come from the local bundle, not the network.
git -c core.hooksPath=/dev/null clone --no-checkout \
  "$DELIVERY/git-bundles/libredwg-web-history.bundle" "$RESTORE/libredwg-web"
git -c core.hooksPath=/dev/null -C "$RESTORE/libredwg-web" checkout --detach \
  2654a724bce3d5f588a0d16b6426a23e3f0fef46

# Only local Git metadata is configured; .gitmodules is NOT edited.
git -c core.hooksPath=/dev/null -C "$RESTORE/libredwg-web" config submodule.jsmn.url \
  "$DELIVERY/git-bundles/jsmn-history.bundle"
git -c core.hooksPath=/dev/null -c protocol.file.allow=always \
  -C "$RESTORE/libredwg-web" submodule update --init --recursive

git -c core.hooksPath=/dev/null clone --no-checkout \
  "$DELIVERY/git-bundles/realdwg-web-history.bundle" "$RESTORE/realdwg-web"
git -c core.hooksPath=/dev/null -C "$RESTORE/realdwg-web" checkout --detach \
  ae0d603bd4e3cad0d8d415c53338d84b14b8c125

# Expected exact commits are listed in section 1.
git -c core.hooksPath=/dev/null -C "$RESTORE/libredwg-web" rev-parse HEAD
git -c core.hooksPath=/dev/null -C "$RESTORE/libredwg-web/jsmn" rev-parse HEAD
git -c core.hooksPath=/dev/null -C "$RESTORE/realdwg-web" rev-parse HEAD

git -c core.hooksPath=/dev/null -C "$RESTORE/libredwg-web" submodule status --recursive
git -c core.hooksPath=/dev/null -C "$RESTORE/libredwg-web" status --porcelain
git -c core.hooksPath=/dev/null -C "$RESTORE/realdwg-web" status --porcelain
shasum -a 256 "$RESTORE/libredwg-web/bindings/javascript/wasm/libredwg-web.wasm"
```

The observed restored WASM SHA-256 was:

```text
2bd963e881cfa08d645e1c869f31ca7ae3e47552276c29e41829cd84250e301a
```

The verification additionally compared **all 2,004 checked-out blobs** (1,324 web + 12 jsmn + 668 converter-monorepo) to the independently saved source Git trees and candidate snapshots. All matched; restored working trees were clean. The WASM matched the pinned source snapshot, npm web 0.7.17 binary and product runtime byte for byte. The complete proof is `evidence/offline-git-restore.json`.

## 3. Native bootstrap and web build: documented, NOT RUN

Do not run these commands on the main workstation or automatically during archive inspection. They execute untrusted upstream code. A future authorized build belongs in an isolated build environment with reviewed inputs. The commands below are the **unmodified upstream README/package-script order**, not a claim they succeeded.

Required standard build tools include a POSIX shell, GNU make, autoconf (configure.ac requires >=2.69), automake, libtool, Perl where generation rules require it, an Emscripten SDK (`emcc`, `emconfigure`, `emmake`), Node and pnpm. Optional gperf regeneration operates on the included `.in` inputs; the generated C tables are already tracked. Exact historical Emscripten/LLVM/ports versions were not established and no substitute version was invented.

Use the **Git-restored** web checkout, with its local bundle origin and initialized pinned jsmn submodule, not the bare source tar tree. `autogen.sh` performs `git fetch --tags`, invokes autoreconf, initializes submodules and uses the existing `build-aux/git-version-gen`; the bundle origin and local submodule URL make those Git dependencies available without inventing `.version` or `.tarball-version`. This description comes from script inspection; autogen itself was not executed.

In the isolated environment, activate the separately selected Emscripten SDK using its own `emsdk_env.sh`, then follow this upstream order:

```sh
# NOT EXECUTED in this task. Run only in an authorized isolated build environment.
# The SDK path is an environment/tool selection, not an asserted historical pin.
. "$EMSDK/emsdk_env.sh"
cd "$RESTORE/libredwg-web"
./autogen.sh
cd bindings/javascript
pnpm install
pnpm build:prepare
pnpm build:obj
pnpm build:wasm
pnpm copy
pnpm build
```

`build:prepare`, `build:obj`, `build:wasm` and `copy` retain their exact flags/paths from `bindings/javascript/package.json`; they are also reproduced as data in `BUILD-INPUTS.json`. In particular, native configuration disables write/JSON/Python/bindings/shared-library/docs paths as specified by that script; linking uses embind, memory growth and mimalloc. `-sUSE_ZLIB=1` asks the Emscripten port system for zlib. No guessed SDK pin or native configuration patch has been added.

`configure`, `Makefile.in`, `src/config.h` and version files are normal generated build outputs. Their source inputs (`configure.ac`, `Makefile.am`, `src/config.h.in`, `m4/`, Git history and the version-generation script) are delivered. All quoted missing `signature.spec` includes are within `#if 0`, so that file is not an active native input. jsmn is supplied at the actual gitlink revision, including its license.

The shipped binary contains an older `...0c9ab_dirty` version string. That does not by itself establish missing/dirty preferred source. Crucially, commit `2654a724...` changes the relevant embind implementation **and** the shipped WASM together, and is itself the pinned tag. There are no later native-source commits between binary introduction and that tag. The build environment's historical generated metadata and bitwise reproduction remain unverified.

## 4. Converter build and product dependency policy: NOT RUN

The complete public monorepo, sibling workspace source, root tools/configs/lockfile, converter source, Vite/TypeScript configs, build-verification profile and package GPL license are delivered. The converter package license is GPL-3.0; the monorepo root's MIT license is not a replacement for it.

The upstream CI uses Node 22.14.0; the root package declares pnpm 10.33.4. Its install/build order is:

```sh
# NOT EXECUTED in this task. Run only in an authorized isolated build environment.
cd "$RESTORE/realdwg-web"
pnpm install --frozen-lockfile
export NODE_OPTIONS='--max-old-space-size=4096'
pnpm run build
```

The original upstream lock resolves **web 0.8.2** when building the converter's original upstream outputs, including its DIST worker. That is a documented upstream dependency, not a newly asserted shipped-product dependency, and no upstream lockfile was rewritten. The task did not prepare an offline npm/SDK cache or add 0.8.2 as a shipped source component.

DWG Viewer's own pinned `package.json` **overrides web to 0.7.17**, confirmed by its `package-lock.json`. Its `tools/vendor-build.js` bundles `lib/AcDbLibreDwgParserWorker.js` and copies the web 0.7.17 WASM separately; it does **not** take the converter's prebundled `dist/libredwg-parser-worker.js` or the different DIST WASM. Therefore restoring the product's shipped source association does not require silently swapping in web 0.8.2 or changing its engine. Product-specific bundling/patch sources and pinned dependency metadata are captured in `evidence/local-vendor-inputs/`; the main extension repository remains the source of the full extension build.

## 5. Verification evidence and limits

| Claim | Type / level | Evidence | Result |
|---|---|---|---|
| Exact source commits and recursive submodule restore offline | State / 1 | Git clones from prerequisite-free local bundles; file protocol only | Verified |
| All restored source blobs match candidate snapshots and saved Git trees | State / 1 | 2,004 exact Git blob/content comparisons | Verified |
| Restored WASM equals pinned npm and runtime WASM | State / 1 | Byte equality and SHA-256 | Verified |
| Source-presence/identity gates reject actual bad inputs | State / 1 | Original mislabeled npm DIST archives and actual different converter-DIST WASM | Rejected as expected; correct sources pass |
| Native source and binary are associated in the same pinned commit | State / 1 | Commit/tree/blob identities and WASM change history | Verified source association; not a compiler execution record |
| Registry SLSA proves publisher trust | State / — | Decoded subject/commit hints only | NOT VERIFIED cryptographically |
| Native/TypeScript builds succeed or reproduce exact binary | Behavior / — | No build or package installation performed | NOT RUN |
| GPL legal compliance is certified | — | Engineering source-delivery work only | NOT CLAIMED |

Unknown historical compiler versions, the older version stamp and the absence of an offline package cache are **not treated as proof of missing preferred source**. No factual necessity to request upstream sources, rebuild runtime WASM or change libraries was established by those observations.

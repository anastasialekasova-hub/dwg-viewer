import { DwgDatabase } from '@mlightcad/libredwg-web';
export declare function parseDwg(data: string | ArrayBuffer): Promise<{
    database: DwgDatabase;
    stats: {
        unknownEntityCount: number;
    };
}>;
//# sourceMappingURL=AcDbLibreDwgConverterUtil.d.ts.map
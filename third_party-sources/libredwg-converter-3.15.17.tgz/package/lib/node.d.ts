export { AcDbLibreDwgMainThreadConverter } from './AcDbLibreDwgMainThreadConverter.js';
//# sourceMappingURL=node.d.ts.map
export { AcDbLibreDwgConverter } from './AcDbLibreDwgConverter.js';
//# sourceMappingURL=index.d.ts.map
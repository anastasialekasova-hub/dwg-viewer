import type { DwgDatabase } from '@mlightcad/libredwg-web';
/**
 * Extracts a drawing-level BMP/PNG thumbnail from raw DWG bytes.
 *
 * LibreDWG's `dwg_bmp` misses some files (notably AC1021 drawings that still
 * store the classic header `previewAddress` image). This helper reads that
 * layout so {@link DwgDatabase.thumbnailImage} can be filled when LibreDWG
 * leaves it empty.
 *
 * Preview payloads are usually headerless DIBs (`biSize === 40`), not full BMP
 * files — callers should run them through `acdbThumbnailImageToDataUrl` / a BMP
 * decoder that accepts DIBs.
 *
 * When both BMP (code 2) and PNG (code 6) entries exist, PNG is preferred.
 *
 * @returns Thumbnail bytes (bmp/png entry), or `undefined` when none exist.
 */
export declare function acdbExtractDwgThumbnailImage(fileBytes: Uint8Array): Uint8Array | undefined;
/**
 * Ensures {@link DwgDatabase.thumbnailImage} is populated when LibreDWG's
 * `dwg_bmp` / `convert` left it empty but the DWG file still embeds a preview.
 */
export declare function acdbEnsureDwgThumbnailImage(model: DwgDatabase, fileBytes: Uint8Array): void;
//# sourceMappingURL=extractDwgThumbnailImage.d.ts.map
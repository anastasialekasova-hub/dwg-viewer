import type { AcDbDatabaseConverterConfig, AcDbParsingTaskResult } from '@mlightcad/data-model';
import type { DwgDatabase } from '@mlightcad/libredwg-web';
import { AcDbLibreDwgConverter } from './AcDbLibreDwgConverter.js';
/**
 * LibreDWG converter that parses on the current thread (no Web Worker).
 *
 * Intended for Node and other environments without a reliable worker + WASM
 * loader. Shares {@link parseDwg} with the browser worker, including the
 * classic `previewAddress` thumbnail fallback.
 *
 * Import from `@mlightcad/libredwg-converter/node` so the browser UMD bundle
 * stays free of LibreDWG WASM.
 */
export declare class AcDbLibreDwgMainThreadConverter extends AcDbLibreDwgConverter {
    constructor(config?: AcDbDatabaseConverterConfig);
    protected parse(data: ArrayBuffer): Promise<AcDbParsingTaskResult<DwgDatabase>>;
}
//# sourceMappingURL=AcDbLibreDwgMainThreadConverter.d.ts.map
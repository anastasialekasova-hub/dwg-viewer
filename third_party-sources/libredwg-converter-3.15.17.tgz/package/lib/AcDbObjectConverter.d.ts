import { AcDbBlkRefObjectContextData, AcDbDictionaryVar, AcDbDimensionObjectContextData, AcDbHatchScaleContextData, AcDbLayerFilter, AcDbLayerIndex, AcDbLeaderObjectContextData, AcDbMLeaderObjectContextData, AcDbMLeaderStyle, AcDbMTextAttributeObjectContextData, AcDbMTextObjectContextData, AcDbScale, AcDbTextObjectContextData, AcDbXrecord } from '@mlightcad/data-model';
import { DwgCommonObject, DwgLayerFilterObject, DwgLayerIndexObject, DwgMLeaderStyleObject, DwgXRecordObject } from '@mlightcad/libredwg-web';
/** LibreDWG SCALE object (when exposed by libredwg-web). */
export interface LibreDwgScaleObject extends DwgCommonObject {
    name?: string;
    paperUnits?: number;
    drawingUnits?: number;
    isUnitScale?: boolean;
    flag?: number;
}
/** LibreDWG DICTIONARYVAR object (when exposed by libredwg-web). */
export interface LibreDwgDictionaryVarObject extends DwgCommonObject {
    schema?: number;
    value?: string;
    strvalue?: string;
}
/** LibreDWG MTEXTOBJECTCONTEXTDATA object (when exposed by libredwg-web). */
export interface LibreDwgMTextObjectContextDataObject extends DwgCommonObject {
    classVersion?: number;
    isDefault?: boolean;
    scaleId?: string;
    scaleHandle?: string;
    attachment?: number;
    xAxisDir?: {
        x: number;
        y: number;
        z?: number;
    };
    insertionPoint?: {
        x: number;
        y: number;
        z?: number;
    };
    definedWidth?: number;
    definedHeight?: number;
    extentsWidth?: number;
    extentsHeight?: number;
    columnType?: number;
}
/** LibreDWG dimension object-context-data (when exposed by libredwg-web). */
export interface LibreDwgDimensionObjectContextDataObject extends DwgCommonObject {
    classVersion?: number;
    isDefault?: boolean;
    scaleId?: string;
    scaleHandle?: string;
    /** Anonymous dim block name for this scale (DXF 2). */
    name?: string;
    blockName?: string;
    defPt?: {
        x: number;
        y: number;
        z?: number;
    };
    definitionPoint?: {
        x: number;
        y: number;
        z?: number;
    };
    dimLinePoint?: {
        x: number;
        y: number;
        z?: number;
    };
    _11pt?: {
        x: number;
        y: number;
        z?: number;
    };
}
/** Shared annot-scale context fields exposed by LibreDWG. */
export interface LibreDwgAnnotScaleContextDataObject extends DwgCommonObject {
    classVersion?: number;
    isDefault?: boolean;
    scaleId?: string;
    scaleHandle?: string;
}
export interface LibreDwgTextObjectContextDataObject extends LibreDwgAnnotScaleContextDataObject {
    horizontalMode?: number;
    rotation?: number;
    alignmentPoint?: {
        x: number;
        y: number;
        z?: number;
    };
    position?: {
        x: number;
        y: number;
        z?: number;
    };
}
export interface LibreDwgHatchScaleContextDataObject extends LibreDwgAnnotScaleContextDataObject {
    patternScale?: number;
    scale?: number;
}
export interface LibreDwgBlkRefObjectContextDataObject extends LibreDwgAnnotScaleContextDataObject {
    position?: {
        x: number;
        y: number;
        z?: number;
    };
    insertionPoint?: {
        x: number;
        y: number;
        z?: number;
    };
    rotation?: number;
    scaleX?: number;
    scaleY?: number;
    scaleZ?: number;
    xScale?: number;
    yScale?: number;
    zScale?: number;
}
export interface LibreDwgMLeaderObjectContextDataObject extends LibreDwgAnnotScaleContextDataObject {
    contentScale?: number;
    textHeight?: number;
    arrowheadSize?: number;
    arrowSize?: number;
    textAnchor?: {
        x: number;
        y: number;
        z?: number;
    };
    landingPoint?: {
        x: number;
        y: number;
        z?: number;
    };
}
/**
 * Converts libredwg object records to AcDbObject instances.
 */
export declare class AcDbObjectConverter {
    /**
     * Converts a DWG MLEADERSTYLE object to an AcDbMLeaderStyle.
     */
    convertMLeaderStyle(style: DwgMLeaderStyleObject): AcDbMLeaderStyle;
    /**
     * Converts a DWG LAYER_FILTER object to an AcDbLayerFilter.
     *
     * @param filter - The DWG layer filter object to convert
     * @returns The converted AcDbLayerFilter instance
     */
    convertLayerFilter(filter: DwgLayerFilterObject): AcDbLayerFilter;
    /**
     * Converts a DWG LAYER_INDEX object to an AcDbLayerIndex.
     *
     * @param index - The DWG layer index object to convert
     * @returns The converted AcDbLayerIndex instance
     */
    convertLayerIndex(index: DwgLayerIndexObject): AcDbLayerIndex;
    convertScale(scale: LibreDwgScaleObject): AcDbScale;
    convertDictionaryVar(dictVar: LibreDwgDictionaryVarObject): AcDbDictionaryVar;
    convertMTextObjectContextData(context: LibreDwgMTextObjectContextDataObject): AcDbMTextObjectContextData;
    convertDimensionObjectContextData(context: LibreDwgDimensionObjectContextDataObject): AcDbDimensionObjectContextData;
    convertTextObjectContextData(context: LibreDwgTextObjectContextDataObject): AcDbTextObjectContextData;
    convertHatchScaleContextData(context: LibreDwgHatchScaleContextDataObject): AcDbHatchScaleContextData;
    convertBlkRefObjectContextData(context: LibreDwgBlkRefObjectContextDataObject): AcDbBlkRefObjectContextData;
    convertLeaderObjectContextData(context: LibreDwgAnnotScaleContextDataObject): AcDbLeaderObjectContextData;
    convertMLeaderObjectContextData(context: LibreDwgMLeaderObjectContextDataObject): AcDbMLeaderObjectContextData;
    convertMTextAttributeObjectContextData(context: LibreDwgMTextObjectContextDataObject): AcDbMTextAttributeObjectContextData;
    convertXRecord(xrecord: DwgXRecordObject): AcDbXrecord;
    private applyAnnotScaleContextBase;
    private processCommonAttrs;
}
//# sourceMappingURL=AcDbObjectConverter.d.ts.map